"""Clinnova federated learning package."""
